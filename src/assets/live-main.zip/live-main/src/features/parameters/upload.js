import { call, select } from 'redux-saga/effects';

import { getServerVersionValidator } from '~/features/servers/selectors';
import messageHub from '~/message-hub';

import { JOB_TYPE } from './constants';

const supportsBulkUpload = getServerVersionValidator('>=2.34.1');

/**
 * Handles a parameter upload session to a single drone. Returns a promise that
 * resolves when all the parameters have been uploaded. The promise is extended
 * with a cancellation callback for Redux-saga.
 *
 * @param uavId    the ID of the UAV to upload the parameters to
 * @param payload  the parameters to upload
 */
function* runSingleParameterUpload({ uavId, payload }, options) {
  const { items, meta } = payload ?? {};

  if (!Array.isArray(items)) {
    return;
  }

  const uavItems = items.filter(
    (param) => param.uavId === undefined || param.uavId === uavId
  );
  if (uavItems.length === 0) {
    return;
  }

  const useBulkUpload = yield select(supportsBulkUpload);

  if (useBulkUpload) {
    const parameters = Object.fromEntries(
      uavItems.map(({ name, value }) => [name, value])
    );

    // No need for a timeout here; it utilizes the message hub, which has its
    // own timeout for failed command executions (although it is quite long)
    yield call(
      messageHub.execute.setParameters,
      { uavId, parameters },
      options
    );
  } else {
    for (const { name, value } of uavItems) {
      // No need for a timeout here; it utilizes the message hub, which has its
      // own timeout for failed command executions (although it is quite long)
      yield call(messageHub.execute.setParameter, {
        uavId,
        name,
        value,
      });
    }
  }

  const { shouldReboot } = meta ?? {};
  if (shouldReboot) {
    yield call(messageHub.execute.resetUAV, uavId);
  }
}

const spec = {
  executor: runSingleParameterUpload,
  title: 'Upload parameters',
  type: JOB_TYPE,
};

export default spec;
