import Edit from '@mui/icons-material/Edit';
import Mouse from '@mui/icons-material/Mouse';
import SelectAll from '@mui/icons-material/SelectAll';
import Box from '@mui/material/Box';
import Fade from '@mui/material/Fade';
import type { Theme } from '@mui/material/styles';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import Typography from '@mui/material/Typography';
import type React from 'react';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';

import { makeStyles } from '@skybrush/app-theme-mui';

import { tt } from '~/i18n';

// TODO: Make a factory function for `tt` that is smart enough to support
//       `keyPrefix` and still compatible with `babel-plugin-i18n-extract`
const CATEGORIES = [
  {
    title: tt('show.showConfigurator.interactionHints.category.navigation'),
    icon: Mouse, // TODO: Maybe `PanTool` instead?
    hints: [
      {
        keys: ['Drag'],
        action: tt('show.showConfigurator.interactionHints.action.pan'),
      },
      {
        keys: ['Scroll'],
        action: tt('show.showConfigurator.interactionHints.action.zoom'),
      },
      {
        keys: ['Shift', 'Alt', 'Drag'],
        action: tt('show.showConfigurator.interactionHints.action.rotate'),
      },
    ],
  },
  {
    title: tt('show.showConfigurator.interactionHints.category.selection'),
    icon: SelectAll,
    hints: [
      {
        keys: ['Click'],
        action: tt('show.showConfigurator.interactionHints.action.select'),
      },
      {
        keys: ['Ctrl', 'Click'],
        action: tt(
          'show.showConfigurator.interactionHints.action.toggleSelect'
        ),
      },
      {
        keys: ['Shift', 'Drag'],
        action: tt('show.showConfigurator.interactionHints.action.boxSelect'),
      },
      {
        keys: ['Alt', 'Drag'],
        action: tt('show.showConfigurator.interactionHints.action.boxUnselect'),
      },
    ],
  },
  {
    title: tt('show.showConfigurator.interactionHints.category.manipulation'),
    icon: Edit,
    hints: [
      {
        keys: ['Drag'],
        action: tt(
          'show.showConfigurator.interactionHints.action.moveSelection'
        ),
      },
      {
        keys: ['Alt', 'Drag'],
        action: tt(
          'show.showConfigurator.interactionHints.action.rotateSelection'
        ),
      },
    ],
  },
];

// HACK: Margin based alignment is just an overcomplicated hack,
//       it should probably be replaced with something cleaner...

const useTabsStyles = makeStyles((theme: Theme) => ({
  root: {
    minHeight: 0,
    color: theme.palette.text.primary,
    marginTop: `-${theme.spacing(0.25)}`,
    paddingBottom: theme.spacing(0.5),
  },
  flexContainer: {
    gap: theme.spacing(2),
  },
  indicator: {
    height: 0,
    backgroundColor: 'transparent',
    '&::after': {
      content: '""',
      display: 'block',
      marginTop: `-${theme.spacing(0.5)}`,
      marginLeft: theme.spacing(2.5),
      borderBottom: `2px solid ${theme.palette.text.secondary}`,
    },
  },
}));

const useTabStyles = makeStyles({
  root: {
    minHeight: 0,
    padding: 0,
    opacity: 1,
    display: 'flex',
    flexDirection: 'row',
  },
  selected: {
    background: 'gradient(linear, 0deg, #0000 0%, #f000 100%)',
  },
});

const InteractionHint = ({
  keys,
  action,
}: Readonly<{ keys: string[]; action: string }>): React.JSX.Element => (
  <span>
    {keys.map((k) => (
      <kbd key={k}>{k}</kbd>
    ))}{' '}
    <Typography component='span' variant='body2' color='textSecondary'>
      {action}
    </Typography>
  </span>
);

const InteractionHints = (): React.JSX.Element => {
  const { t } = useTranslation();
  const [active, setActive] = useState(0);
  const tabStyles = useTabStyles();
  const tabsStyles = useTabsStyles();

  return (
    <Box sx={{ height: '50px' }}>
      <Tabs value={active} classes={tabsStyles} style={{ marginBottom: 2 }}>
        {CATEGORIES.map(({ icon: Icon, title }, i) => (
          <Tab
            key={title(t)}
            icon={<Icon fontSize='small' style={{ margin: 0 }} />}
            label={title(t)}
            classes={tabStyles}
            onMouseOver={() => {
              setActive(i);
            }}
          />
        ))}
      </Tabs>

      {CATEGORIES.map((c, i) => (
        <Fade key={c.title(t)} in={active === i}>
          <Box sx={{ position: 'absolute', display: 'flex', gap: 2 }}>
            {c.hints.map((h) => (
              <InteractionHint
                key={h.keys.join('+')}
                keys={h.keys}
                action={h.action(t)}
              />
            ))}
          </Box>
        </Fade>
      ))}
    </Box>
  );
};

export default InteractionHints;
