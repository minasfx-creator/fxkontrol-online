import Button from '@mui/material/Button';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemSecondaryAction from '@mui/material/ListItemSecondaryAction';
import ListItemText from '@mui/material/ListItemText';
import Zoom from '@mui/material/Zoom';
import isNil from 'lodash-es/isNil';
import PropTypes from 'prop-types';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useAsyncFn } from 'react-use';

import { StatusLight } from '@skybrush/mui-components';

import Colors from '~/components/colors';
import { errorToString } from '~/error-handling';
import { useMessageHub } from '~/hooks';

import { COMPASS_CALIB_TIMEOUT } from './constants';
import ListItemProgressBar from './ListItemProgressBar';

const tests = [
  {
    component: 'compass',
    label: 'Calibrate compass',
    type: 'calib',
    timeout: COMPASS_CALIB_TIMEOUT,
  },
  {
    component: 'accel',
    label: 'Calibrate accelerometer',
    type: 'calib',
    timeout: 90 /* accelerometer calibration may take longer */,
  },
  {
    component: 'baro',
    label: 'Calibrate ground pressure',
    type: 'calib',
    timeout: 10,
  },
  {
    component: 'gyro',
    label: 'Calibrate gyroscope',
    type: 'calib',
    timeout: 10,
  },
  {
    component: 'level',
    label: 'Calibrate level position',
    type: 'calib',
    timeout: 10,
  },
  {
    component: 'led',
    label: 'Execute LED test',
    type: 'test',
  },
  {
    component: 'pyro',
    label: 'Execute pyro test',
    needsConfirmation: true,
    type: 'test',
  },
  {
    component: 'motor',
    label: 'Execute motor test',
    needsConfirmation: true,
    type: 'test',
  },
];

const UAVTestButton = ({
  component,
  label,
  needsConfirmation = false,
  timeout,
  type,
  uavId,
}) => {
  const messageHub = useMessageHub();

  // We can store the timeout ID of the pending confirmation in this state and
  // use it to determine whethere there is a currently pending confirmation,
  // as setTimeout returns *positive* integers only.
  // https://developer.mozilla.org/en-US/docs/Web/API/setTimeout#return_value
  const [pendingConfirmation, setPendingConfirmation] = useState(null);
  const [progress, setProgress] = useState(null);
  const [suspended, setSuspended] = useState(false);
  const resumeCallback = useRef(null);
  const lastExecutedUavIdRef = useRef(null);
  const uavIdRef = useRef(uavId);
  uavIdRef.current = uavId;

  const clearPendingConfirmation = useCallback(() => {
    clearTimeout(pendingConfirmation);
    setPendingConfirmation(null);
  }, [pendingConfirmation]);

  useEffect(() => {
    clearPendingConfirmation();
    setProgress(null);
    setSuspended(false);
    resumeCallback.current = null;
  }, [uavId]);

  const askForConfirmation = useCallback(() => {
    clearPendingConfirmation();
    setPendingConfirmation(setTimeout(clearPendingConfirmation, 3000));
  }, [clearPendingConfirmation]);

  const progressHandler = useCallback(
    (progressUAVId, { progress, resume, suspended }) => {
      if (progressUAVId !== uavIdRef.current) {
        return;
      }
      setProgress(progress);
      setSuspended(Boolean(suspended));
      resumeCallback.current = resume;
    },
    []
  );

  const [lastExecutionState, execute] = useAsyncFn(async () => {
    lastExecutedUavIdRef.current = uavId;
    // TODO(ntamas): use the proper UAV-TEST messages designated for this
    await messageHub.sendCommandRequest(
      {
        uavId,
        command: type === 'test' ? 'test' : 'calib',
        args: [String(component)],
      },
      { onProgress: (progress) => progressHandler(uavId, progress), timeout }
    );
    return true;
  }, [component, messageHub, progressHandler, timeout, type, uavId]);

  const executionState =
    lastExecutedUavIdRef.current === uavId
      ? lastExecutionState
      : { loading: false };

  const [, resume] = useAsyncFn(async () => {
    if (resumeCallback.current) {
      return resumeCallback.current();
    } else {
      throw new Error('No resume callback has been provided');
    }
  }, []);

  const giveConfirmation = useCallback(() => {
    clearPendingConfirmation();
    if (suspended) {
      resume();
    } else {
      execute();
    }
  }, [clearPendingConfirmation, execute, resume, suspended]);

  return (
    <ListItemButton
      onClick={needsConfirmation ? askForConfirmation : giveConfirmation}
    >
      <StatusLight
        status={
          suspended
            ? 'warning'
            : executionState.loading
              ? 'next'
              : executionState.error
                ? 'error'
                : isNil(executionState.value)
                  ? 'off'
                  : executionState.value
                    ? 'success'
                    : 'error'
        }
      />
      <ListItemText
        primary={
          suspended
            ? `${progress.message || 'Operation suspended'}. Click to resume.`
            : progress && (!executionState.error || executionState.loading)
              ? `${progress.message || label}`
              : label
        }
        secondary={
          !executionState.loading && executionState.error ? (
            errorToString(executionState.error)
          ) : progress ? (
            /* Prefer progress bars even in suspended state */
            <ListItemProgressBar progress={progress} />
          ) : suspended ? (
            /* If we are suspended but we don't have progress info, show an indefinite progress bar */
            <ListItemProgressBar />
          ) : null
        }
      />
      <ListItemSecondaryAction>
        {/* TODO: Change to `Slide` from right when switching to Material UI v5,
                  as that version supports setting a `container`. */}
        <Zoom in={Boolean(pendingConfirmation)}>
          <Button
            style={{ color: Colors.seriousWarning }}
            onClick={giveConfirmation}
          >
            Confirm
          </Button>
        </Zoom>
      </ListItemSecondaryAction>
    </ListItemButton>
  );
};

UAVTestButton.propTypes = {
  component: PropTypes.string,
  label: PropTypes.string,
  needsConfirmation: PropTypes.bool,
  uavId: PropTypes.string,
  timeout: PropTypes.number,
  type: PropTypes.oneOf(['calib', 'test']),
};

const UAVTestsPanel = ({ uavId }) => {
  return (
    <List dense>
      {tests.map(({ component, ...props }) => (
        <UAVTestButton
          key={component}
          component={component}
          uavId={uavId}
          {...props}
        />
      ))}
    </List>
  );
};

UAVTestsPanel.propTypes = {
  uavId: PropTypes.string,
};

export default UAVTestsPanel;
