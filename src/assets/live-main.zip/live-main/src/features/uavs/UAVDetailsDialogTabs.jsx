import Tab from '@mui/material/Tab';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import { DialogTabs } from '@skybrush/mui-components';

import {
  getSelectedTabInUAVDetailsDialog,
  setSelectedTabInUAVDetailsDialog,
} from './details';

/**
 * Presentation component for the dialog that allows the user to inspect the
 * details of a specific UAV.
 */
const UAVDetailsDialogTabs = ({
  dragHandleId,
  value = 'preflight',
  ...rest
}) => (
  <DialogTabs
    alignment='left'
    dragHandle={dragHandleId}
    value={value}
    {...rest}
  >
    <Tab label='Preflight' value='preflight' />
    <Tab label='Tests' value='tests' />
    <Tab label='Messages' value='messages' />
    <Tab label='Logs' value='logs' />
  </DialogTabs>
);

UAVDetailsDialogTabs.propTypes = {
  dragHandleId: PropTypes.string,
  value: PropTypes.string,
};

export default connect(
  // mapStateToProps
  (state) => ({
    value: getSelectedTabInUAVDetailsDialog(state),
  }),

  // mapDispatchToProps
  {
    onChange: (_event, value) => setSelectedTabInUAVDetailsDialog(value),
  }
)(UAVDetailsDialogTabs);
