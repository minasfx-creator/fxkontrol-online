import ConnectionIcon from '@mui/icons-material/Power';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import { GenericHeaderButton, LazyTooltip } from '@skybrush/mui-components';

import ServerConnectionStatusMiniList from '~/components/ServerConnectionStatusMiniList';
import ServerConnectionStatusBadge from '~/components/badges/ServerConnectionStatusBadge';
import { showServerSettingsDialog } from '~/features/servers/actions';

const ServerConnectionSettingsButton = ({ hideTooltip, ...rest }) => {
  const body = (
    <GenericHeaderButton {...rest}>
      <ServerConnectionStatusBadge />
      <ConnectionIcon />
    </GenericHeaderButton>
  );

  return hideTooltip ? (
    body
  ) : (
    <LazyTooltip content={<ServerConnectionStatusMiniList />}>
      {body}
    </LazyTooltip>
  );
};

ServerConnectionSettingsButton.propTypes = {
  hideTooltip: PropTypes.bool,
  onClick: PropTypes.func,
};

export default connect(
  // mapStateToProps
  null,
  // mapDispatchToProps
  {
    onClick: showServerSettingsDialog,
  }
)(ServerConnectionSettingsButton);
