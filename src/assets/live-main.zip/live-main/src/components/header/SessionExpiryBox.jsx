import Box from '@mui/material/Box';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import TimeAgo from 'react-timeago';

const headingFormatter = (_value, _unit, suffix) =>
  suffix === 'ago' ? 'Session expired' : 'Session expires';

const SessionExpiryBox = ({ expiresAt }) =>
  expiresAt ? (
    <Box
      style={{ color: 'white', fontSize: '0.875rem', textAlign: 'right' }}
      sx={{ alignSelf: 'center', px: 1 }}
    >
      <div style={{ color: 'rgba(255, 255, 255, 0.54)' }}>
        <TimeAgo date={expiresAt} formatter={headingFormatter} />
      </div>
      <div>
        <b>
          <TimeAgo date={expiresAt} />
        </b>
      </div>
    </Box>
  ) : null;

SessionExpiryBox.propTypes = {
  expiresAt: PropTypes.number,
};

export default connect(
  // mapStateToProps
  (state) => ({
    expiresAt: state.session.expiresAt,
  })
)(SessionExpiryBox);
