import Help from '@mui/icons-material/HelpOutline';
import config from 'config';
import { Translation } from 'react-i18next';

import { GenericHeaderButton } from '@skybrush/mui-components';

const showHelp = () => {
  if (config.urls.help) {
    window.open(config.urls.help, '_blank');
  }
};

const HelpButton = () => (
  <Translation>
    {(t) => (
      <GenericHeaderButton tooltip={t('help')} onClick={showHelp}>
        <Help />
      </GenericHeaderButton>
    )}
  </Translation>
);

export default HelpButton;
