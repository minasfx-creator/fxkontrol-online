import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { orderBy } from 'natural-orderby';
import PropTypes from 'prop-types';

import { formatMissionId } from '~/utils/formatting';

import DronePlaceholder from './DronePlaceholder';

/**
 * Presentation component that receives a list of drone IDs or mapping slot
 * indices and formats them nicely, truncating the list as appropriate if it
 * is too long.
 */
const DronePlaceholderList = ({
  actions,
  emptyMessage,
  items = [],
  maxCount = 8,
  preferEmptyMessage,
  successMessage,
  title,
  ...rest
}) => {
  const formattedAndSortedIds = orderBy(
    items
      .slice(0, maxCount)
      .map((item) =>
        typeof item === 'number' ? formatMissionId(item) : String(item)
      )
  );
  return (
    <Box
      {...rest}
      sx={[
        {
          mt: 1,
        },
        ...(Array.isArray(rest.sx) ? rest.sx : [rest.sx]),
      ]}
    >
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'center',
          minHeight: 44,
        }}
      >
        {title && (
          <Box key='lead' sx={{ minWidth: 85 }}>
            {title}
          </Box>
        )}
        {formattedAndSortedIds.map((itemId, index) => (
          <Box key={itemId} sx={{ ml: index > 0 || title ? 1 : 0 }}>
            <DronePlaceholder label={itemId} />
          </Box>
        ))}
        {items.length > maxCount ? (
          <Box key='more' sx={{ ml: 1, color: 'text.secondary' }}>
            <Typography variant='body2'>
              + {items.length - maxCount} more
            </Typography>
          </Box>
        ) : null}
        {items.length === 0 ? (
          successMessage && !preferEmptyMessage ? (
            <>
              <Box key='ok' sx={{ ml: title ? 1 : 0 }}>
                <DronePlaceholder label='OK' status='success' />
              </Box>
              <Box key='successMessage' sx={{ color: 'success.main', ml: 1 }}>
                <Typography variant='body2'>{successMessage}</Typography>
              </Box>
            </>
          ) : (
            <Box
              key='emptyMessage'
              sx={{ color: title ? 'text.secondary' : null, ml: title ? 1 : 0 }}
            >
              <Typography variant='body2'>{emptyMessage}</Typography>
            </Box>
          )
        ) : null}
        {actions && (
          <>
            <Box key='padding' sx={{ flex: 1 }} />
            <Box key='actions' sx={{ ml: 1 }}>
              {actions}
            </Box>
          </>
        )}
      </Box>
    </Box>
  );
};

DronePlaceholderList.propTypes = {
  actions: PropTypes.oneOfType([
    PropTypes.node,
    PropTypes.arrayOf(PropTypes.node),
  ]),
  emptyMessage: PropTypes.node,
  items: PropTypes.arrayOf(
    PropTypes.oneOfType([PropTypes.number, PropTypes.string])
  ),
  maxCount: PropTypes.number,
  preferEmptyMessage: PropTypes.bool,
  successMessage: PropTypes.node,
  title: PropTypes.string,
};

export default DronePlaceholderList;
