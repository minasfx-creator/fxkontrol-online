import config from 'config';

import Box from '@mui/material/Box';
import Checkbox from '@mui/material/Checkbox';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormGroup from '@mui/material/FormGroup';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import PropTypes from 'prop-types';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';

import { FormHeader as Header, ThemeSelector } from '@skybrush/mui-components';

import CoordinateSystemFields from '~/components/CoordinateSystemFields';
import {
  setFlatEarthCoordinateSystemOrientation,
  setFlatEarthCoordinateSystemOrigin,
  setFlatEarthCoordinateSystemType,
} from '~/features/map/origin';
import { updateAppSettings } from '~/features/settings/slice';
import { enabledLanguages } from '~/i18n';
import { CoordinateFormat, describeCoordinateFormat } from '~/model/settings';
import { getMapOriginRotationAngle } from '~/selectors/map';

const coordinateFormatOrder = [
  CoordinateFormat.DEGREES,
  CoordinateFormat.DEGREES_MINUTES,
  CoordinateFormat.DEGREES_MINUTES_SECONDS,
  CoordinateFormat.SIGNED_DEGREES,
  CoordinateFormat.SIGNED_DEGREES_MINUTES,
  CoordinateFormat.SIGNED_DEGREES_MINUTES_SECONDS,
];

// default value for 'language' ensures that updating from a non-localized
// version does not leave the "Language" dropdown empty

const DisplayTabPresentation = ({ language = 'en', t, ...props }) => (
  <>
    <Box>
      <FormControl fullWidth variant='filled'>
        <InputLabel id='language-selector-label'>
          {t('settings.display.language')}
        </InputLabel>
        <Select
          labelId='language-selector-label'
          name='language'
          value={language}
          onChange={props.onFieldChanged}
        >
          {enabledLanguages.map(({ code, label }) => (
            <MenuItem key={code} value={code}>
              {label}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>

    <Box sx={{ my: 2 }}>
      {/* TODO(vp): gap should be used on the parent component instead... */}
      <ThemeSelector value={props.theme} onChange={props.onFieldChanged} />
    </Box>

    <Box>
      <FormControl fullWidth variant='filled'>
        <InputLabel id='coordinate-format-label'>
          {t('settings.display.coordinateFormat')}
        </InputLabel>
        <Select
          labelId='coordinate-format-label'
          name='coordinateFormat'
          value={props.coordinateFormat}
          onChange={props.onFieldChanged}
        >
          {coordinateFormatOrder.map((coordinateFormat) => (
            <MenuItem key={coordinateFormat} value={coordinateFormat}>
              {describeCoordinateFormat(coordinateFormat)}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      <FormGroup>
        <Header>{t('settings.display.mapWidgets')}</Header>
        <FormControlLabel
          label={t('settings.display.showMouseCoordinates')}
          control={
            <Checkbox
              checked={props.showMouseCoordinates}
              name='showMouseCoordinates'
              onChange={props.onCheckboxToggled}
            />
          }
        />
        <FormControlLabel
          label={t('settings.display.showScaleLine')}
          control={
            <Checkbox
              checked={props.showScaleLine}
              name='showScaleLine'
              onChange={props.onCheckboxToggled}
            />
          }
        />
      </FormGroup>

      <FormGroup>
        <Header>{t('settings.display.flatEarthCoordinateSystem')}</Header>
        <CoordinateSystemFields
          origin={props.origin}
          originLabel={t('settings.display.mapOrigin')}
          orientation={props.orientation}
          type={props.coordinateSystemType}
          onOrientationChanged={props.onOrientationChanged}
          onOriginChanged={props.onOriginChanged}
          onTypeChanged={props.onCoordinateSystemTypeChanged}
        />
      </FormGroup>

      <FormGroup>
        <Header>{t('settings.display.operationModes')}</Header>
        <FormControlLabel
          label={t('settings.display.optimizeForSingleUAV')}
          control={
            <Checkbox
              checked={props.optimizeForSingleUAV}
              disabled={config.optimizeForSingleUAV.force}
              name='optimizeForSingleUAV'
              onChange={props.onCheckboxToggled}
            />
          }
        />
        <FormControlLabel
          label={t('settings.display.optimizeUIForTouch')}
          control={
            <Checkbox
              checked={props.optimizeUIForTouch}
              disabled={config.optimizeUIForTouch.force}
              name='optimizeUIForTouch'
              onChange={props.onCheckboxToggled}
            />
          }
        />
      </FormGroup>

      <FormGroup>
        <Header>{t('settings.display.miscellaneous')}</Header>
        <FormControlLabel
          label={t('settings.display.hideInactiveSegmentsOnDarkLCD')}
          control={
            <Checkbox
              checked={props.hideInactiveSegmentsOnDarkLCD}
              name='hideInactiveSegmentsOnDarkLCD'
              onChange={props.onCheckboxToggled}
            />
          }
        />
        <FormControlLabel
          label={t('settings.display.enableExperimentalFeatures')}
          control={
            <Checkbox
              checked={props.experimentalFeaturesEnabled}
              name='experimentalFeaturesEnabled'
              onChange={props.onCheckboxToggled}
            />
          }
        />
      </FormGroup>
    </Box>
  </>
);

DisplayTabPresentation.propTypes = {
  coordinateFormat: PropTypes.oneOf(coordinateFormatOrder),
  coordinateSystemType: PropTypes.oneOf(['neu', 'nwu']),
  experimentalFeaturesEnabled: PropTypes.bool,
  language: PropTypes.string,
  origin: PropTypes.arrayOf(PropTypes.number),
  onCheckboxToggled: PropTypes.func,
  onCoordinateSystemTypeChanged: PropTypes.func,
  onFieldChanged: PropTypes.func,
  onOriginChanged: PropTypes.func,
  onOrientationChanged: PropTypes.func,
  optimizeForSingleUAV: PropTypes.bool,
  optimizeUIForTouch: PropTypes.bool,
  orientation: PropTypes.number,
  hideInactiveSegmentsOnDarkLCD: PropTypes.bool,
  showMouseCoordinates: PropTypes.bool,
  showScaleLine: PropTypes.bool,
  t: PropTypes.func,
  theme: PropTypes.oneOf(['auto', 'dark', 'light']),
};

export default connect(
  // mapStateToProps
  (state) => ({
    coordinateSystemType: state.map.origin.type,
    origin: state.map.origin.position,
    orientation: getMapOriginRotationAngle(state),
    ...state.settings.display,
  }),
  // mapDispatchToProps
  (dispatch) => ({
    onCheckboxToggled(event) {
      dispatch(
        updateAppSettings('display', {
          [event.target.name]: event.target.checked,
        })
      );
    },

    onCoordinateSystemTypeChanged(event) {
      dispatch(setFlatEarthCoordinateSystemType(event.target.value));
    },

    onFieldChanged(event) {
      dispatch(
        updateAppSettings('display', {
          [event.target.name]: event.target.value,
        })
      );
    },

    onOriginChanged(value) {
      dispatch(setFlatEarthCoordinateSystemOrigin(value));
    },

    onOrientationChanged(value) {
      dispatch(setFlatEarthCoordinateSystemOrientation(value || 0));
    },
  })
)(withTranslation()(DisplayTabPresentation));
